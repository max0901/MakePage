const banner1 = document.querySelector("#show_inner1");
const banner2 = document.querySelector("#show_inner2");
const bannerLi1 = document.querySelectorAll("#show_inner1 li");
const bannerLi2 = document.querySelectorAll("#show_inner2 li");
const prev = document.querySelector(".slide_btn1 .prev");
const next = document.querySelector(".sldie_btn1 .next");

const size = bannerLi1[0].clientWidth;
let cnt = 0;

next.addEventListener("click", () => {
  if (cnt < bannerLi1.length - 1) {
    cnt++;
    banner1.style.transform = "translateX(" + -size * cnt + "px)";
  } else if (cnt === bannerLi1.length - 1) {
    cnt = 0;
    banner1.style.transform = "translateX(" + -size * cnt + "px)";
  }
});

prev.addEventListener("click", () => {
  if (cnt > 0) {
    cnt--;
    banner1.style.transform = "translateX(" + -size * cnt + "px)";
  } else if (cnt === 0) {
    cnt = bannerLi1.length - 1;
    banner1.style.transform = "translateX(" + -size * cnt + "px)";
  }
});
